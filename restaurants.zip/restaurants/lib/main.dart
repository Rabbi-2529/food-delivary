import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:restaurants/loginpage.dart';
import 'package:restaurants/screens/home_screen.dart';

void main() {
  runApp(const MYApp());
}

class MYApp extends StatelessWidget {
  const MYApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Loginpage(),
    );
  }
}
