import 'package:restaurants/model/restaurant.dart';
import 'package:restaurants/model/food.dart';
import 'package:restaurants/model/restaurant.dart';

class Order {
  final Restaurant? restaurant;
  final Food? food;
  final String? date;
  final int? quantity;

  Order({
    this.date,
    this.restaurant,
    this.food,
    this.quantity,
  });
}
