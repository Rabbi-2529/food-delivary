import 'package:flutter/material.dart';
import 'package:restaurants/data/data.dart';
import 'package:restaurants/model/food.dart';
import 'package:restaurants/model/restaurant.dart';

class Restaurantdetails extends StatefulWidget {
  Restaurant? restaurant;
  Restaurantdetails({this.restaurant});

  @override
  State<Restaurantdetails> createState() => _RestaurantdetailsState();
}

class _RestaurantdetailsState extends State<Restaurantdetails> {
  _buildmenuitem(Food menuitem) {
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.all(8.0),
          height: 140,
          width: 140,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15.0),
              image: DecorationImage(
                  fit: BoxFit.cover,
                  image: AssetImage("${menuitem.imageUrl}"))),
          
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Stack(
            children: [
              Image(
                image: AssetImage('${widget.restaurant!.imageUrl}'),
                height: 210,
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.cover,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: Icon(
                        Icons.arrow_back,
                        color: Colors.white,
                      )),
                  IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: Icon(
                        Icons.favorite,
                        color: Colors.red,
                      )),
                ],
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "${widget.restaurant!.name}",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                    ),
                    Text("${widget.restaurant!.address}")
                  ],
                ),
              ),
              Text("0.2 miles"),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                height: 40,
                width: 80,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: Colors.deepOrange),
                child: Center(child: Text("Review")),
              ),
              Container(
                height: 40,
                width: 80,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: Colors.deepOrange),
                child: Center(child: Text("Contact")),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            "Menu",
            style: TextStyle(fontSize: 20, color: Colors.blue),
          ),
          SizedBox(
            height: 10,
          ),
          Expanded(
              child: GridView.count(
            crossAxisCount: 2,
            children: List.generate(widget.restaurant!.menu!.length, (index) {
              Food food = widget.restaurant!.menu![index];
              return _buildmenuitem(food);
            }),
          ))
        ],
      ),
    );
  }
}
